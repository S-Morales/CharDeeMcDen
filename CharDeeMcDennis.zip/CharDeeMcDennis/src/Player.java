import java.awt.Color;


public class Player {

	private String name;
	private int score;
	// boolean to hold whether player is on the board and can take a turn or stuck
	// in the swamp/pit
	private boolean onBoard;
	private Color color;
	static int playerNumber;

	public Player(String name, int score, boolean onBoard, Color color) {
		super();
		this.name = name;
		this.score = score;
		this.onBoard = onBoard;
		this.color = color;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public boolean isOnBoard() {
		return onBoard;
	}

	public void setOnBoard(boolean onBoard) {
		this.onBoard = onBoard;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

}
