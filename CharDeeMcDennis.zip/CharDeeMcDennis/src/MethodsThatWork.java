import java.awt.Color;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class MethodsThatWork {
	

	public static ArrayList<Player> arrayListOfPlayers;

	public MethodsThatWork() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
/**
 * This method creates player objects and stores them in an arraylist<player>
 * In it the user is asked for input for player names, and they can choose the color 
 * or maybe later image
 * by which they will be represented on the board.
 * @return
 */
	public static ArrayList<Player> createPlayers() {

		// first find out how many people are playing. practicing with 2 for ease of
		// debugging. This should be easily scalable to up to maybe 7? should we cap
		// it???
		String amountOfPlayers = JOptionPane.showInputDialog(null, "Enter the number of people playing: ",
				"How many players?", JOptionPane.QUESTION_MESSAGE);

		// parse the first input to an int so we can use it other places
		Player.playerNumber = Integer.parseInt(amountOfPlayers);

		// formally create the arraylist of players so it can actually hold shit
		arrayListOfPlayers = new ArrayList<Player>(Player.playerNumber);

		// ask for player name, and assign them a color
		// this may later be changed to a game piece once I learn how to upload images
		// to be used
		for (int i = 0; i < Player.playerNumber; i++) {
			// create an empty player object
			Player player = new Player(null, 0, true, null);
			// set the name based on input
			player.setName(JOptionPane.showInputDialog(null, "Enter the name of player " + (i + 1) + "!",
					"Player Names", JOptionPane.QUESTION_MESSAGE));
			// everyone starts with a score of 0
			player.setScore(0);
			// set the player's color based on chooser
			// may later be image
			// COLOR CHOOSER HERE
			// temporarily set to avoid NPE
			player.setColor(Color.BLUE);
			// everyone starts on the board
			player.setOnBoard(true);

			// add the player, given that everything was added correctly
			if (player.getColor() != null) {
				if (player.getName() != null) {
					if (player.getScore() == 0) {
						if (player.isOnBoard() == true) {
							arrayListOfPlayers.add(player);
						} else
							System.out.println("player not on board");
					} else
						System.out.println("player has no score");
				} else
					System.out.println("player has no name");

			} else
				System.out.println("player got no color");

		}

		return arrayListOfPlayers;

	}

}
