import java.awt.Color;

public class Card {
	
	final Color PINK_QUESTION_CARD = Color.PINK;
	final Color YELLOW_DARE_CARD = Color.YELLOW;
	final Color GREEN_MINIGAME_CARD = Color.GREEN;
	
	
	private Color typeOfCard;
	private String question;
	private String quote;
	

	public Card() {
		// TODO Auto-generated constructor stub
		
		
	}


	public Color getTypeOfCard() {
		return typeOfCard;
	}


	public void setTypeOfCard(Color typeOfCard) {
		this.typeOfCard = typeOfCard;
	}


	public String getQuestion() {
		return question;
	}


	public void setQuestion(String question) {
		this.question = question;
	}


	public String getQuote() {
		return quote;
	}


	public void setQuote(String quote) {
		this.quote = quote;
	}

}
