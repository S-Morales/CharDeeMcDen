import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;

import java.util.Scanner;

public class DebugTestingGround {

	public static ArrayList<Card> arrayListOfcards;

	public DebugTestingGround() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		buildDeckOfCards();
		
		System.out.println(arrayListOfcards.get(0).getQuestion());
		System.out.println(arrayListOfcards.get(1).getQuestion());
		System.out.println(arrayListOfcards.get(2).getQuestion());
		System.out.println(arrayListOfcards.get(3).getQuestion());
		System.out.println(arrayListOfcards.get(4).getQuestion());

	}

	public static ArrayList<Card> buildDeckOfCards() {

		File questionFile = new File("Questions.txt");
		arrayListOfcards = new ArrayList<Card>(5);

		try {
			Scanner scanner = new Scanner(questionFile);
			
			while (scanner.hasNextLine()) {
				Card card = new Card();
				card.setQuestion(scanner.nextLine());
				arrayListOfcards.add(card);
				
			}
			scanner.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found!");
			e.printStackTrace();
		}
		
		

		return arrayListOfcards;
	}

}
